package com.example.proyectofinal001

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
